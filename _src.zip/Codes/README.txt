
-- SUMMARY --

The FB Feed Block module is a demo module used for the Packt Video course to introduce Drupal 7 module development.  This module creates a block that shows feeds from your Facebook account.


-- REQUIREMENTS/DEPENDENCIES --

Feeds module:  https://drupal.org/project/feeds


-- INSTALLATION --

* Install and enable as usual, see https://drupal.org/documentation/install/modules-themes/modules-7 for further information.


-- CONFIGURATION --

* Follow the Packt Video course for configuration instructions.